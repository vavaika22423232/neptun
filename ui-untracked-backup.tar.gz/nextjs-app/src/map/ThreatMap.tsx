'use client';

import { useEffect, useMemo, useRef } from 'react';
import maplibregl from 'maplibre-gl';
import 'maplibre-gl/dist/maplibre-gl.css';
import { buildThreatMapStyle } from '@/map/map-style';
import { ensureThreatLayerIcons } from '@/map/threat-icons';
import { entitiesToFeatureCollection } from '@/map/threat-source';
import { THREAT_ENTITY_TYPES, type RenderEntity, type ThreatEntityType } from '@/map/threat-types';
import { useThreatStore } from '@/store/threat-store';

const UKRAINE_CENTER: [number, number] = [31.1656, 48.3794];

function sourceId(type: ThreatEntityType) {
  return `threats-${type}`;
}

function layerId(type: ThreatEntityType) {
  return `threat-symbols-${type}`;
}

function emptyCollection() {
  return { type: 'FeatureCollection' as const, features: [] };
}

function setTypeSourceData(map: maplibregl.Map, type: ThreatEntityType, entities: RenderEntity[]) {
  const source = map.getSource(sourceId(type)) as maplibregl.GeoJSONSource | undefined;
  if (!source) return;
  source.setData(entitiesToFeatureCollection(entities, { [type]: true } as Record<ThreatEntityType, boolean>));
}

export default function ThreatMap() {
  const mapNodeRef = useRef<HTMLDivElement | null>(null);
  const mapRef = useRef<maplibregl.Map | null>(null);
  const rafRef = useRef<number | null>(null);
  const entitiesRef = useRef<Map<string, RenderEntity>>(new Map());
  const layersRef = useRef(useThreatStore.getState().layers);
  const focusModeRef = useRef(useThreatStore.getState().focusMode);
  const performanceModeRef = useRef(useThreatStore.getState().performanceMode);
  const lastFocusAtRef = useRef(0);

  const initialStyle = useMemo(() => buildThreatMapStyle(), []);

  useEffect(() => {
    const node = mapNodeRef.current;
    if (!node || mapRef.current) return;

    const map = new maplibregl.Map({
      container: node,
      style: initialStyle,
      center: UKRAINE_CENTER,
      zoom: 5.2,
      minZoom: 4,
      maxZoom: 12,
      attributionControl: false,
      fadeDuration: 0,
      dragRotate: false,
      touchPitch: false,
    });
    mapRef.current = map;

    map.addControl(new maplibregl.NavigationControl({ visualizePitch: false }), 'bottom-right');
    map.on('load', () => {
      ensureThreatLayerIcons(map);
      for (const type of THREAT_ENTITY_TYPES) {
        map.addSource(sourceId(type), {
          type: 'geojson',
          data: emptyCollection(),
        });
        map.addLayer({
          id: layerId(type),
          type: 'symbol',
          source: sourceId(type),
          layout: {
            'icon-image': `threat-${type}`,
            'icon-size': [
              'interpolate',
              ['linear'],
              ['zoom'],
              4,
              type === 'explosion' ? 0.22 : 0.18,
              8,
              type === 'explosion' ? 0.34 : 0.28,
            ],
            'icon-allow-overlap': true,
            'icon-ignore-placement': true,
            'icon-rotation-alignment': 'map',
            'icon-rotate': ['get', 'bearing'],
          },
          paint: {
            'icon-opacity': ['get', 'opacity'],
          },
        });
      }
    });

    return () => {
      if (rafRef.current != null) cancelAnimationFrame(rafRef.current);
      map.remove();
      mapRef.current = null;
    };
  }, [initialStyle]);

  useEffect(() => {
    return useThreatStore.subscribe((state) => {
      entitiesRef.current = state.entities;
      layersRef.current = state.layers;
      focusModeRef.current = state.focusMode;
      performanceModeRef.current = state.performanceMode;
      const map = mapRef.current;
      if (!map?.isStyleLoaded()) return;
      for (const type of THREAT_ENTITY_TYPES) {
        map.setLayoutProperty(layerId(type), 'visibility', state.layers[type] ? 'visible' : 'none');
      }
    });
  }, []);

  useEffect(() => {
    const tick = () => {
      const map = mapRef.current;
      if (map?.isStyleLoaded()) {
        const buckets = new Map<ThreatEntityType, RenderEntity[]>();
        for (const type of THREAT_ENTITY_TYPES) buckets.set(type, []);

        const t = performance.now();
        for (const entity of entitiesRef.current.values()) {
          if (!layersRef.current[entity.type]) continue;
          if (performanceModeRef.current) {
            entity.renderLat = entity.targetLat;
            entity.renderLng = entity.targetLng;
          } else {
            const p = Math.min(1, (t - entity.animationStartedAt) / entity.animationDurationMs);
            const eased = 1 - Math.pow(1 - p, 3);
            entity.renderLat = entity.fromLat + (entity.targetLat - entity.fromLat) * eased;
            entity.renderLng = entity.fromLng + (entity.targetLng - entity.fromLng) * eased;
          }
          buckets.get(entity.type)?.push(entity);
        }

        for (const type of THREAT_ENTITY_TYPES) {
          setTypeSourceData(map, type, buckets.get(type) ?? []);
        }

        if (focusModeRef.current && t - lastFocusAtRef.current > 5000) {
          let nearest: RenderEntity | null = null;
          for (const entity of entitiesRef.current.values()) {
            if (entity.status === 'lost' || !layersRef.current[entity.type]) continue;
            if (!nearest || entity.timestamp > nearest.timestamp) nearest = entity;
          }
          if (nearest) {
            lastFocusAtRef.current = t;
            map.easeTo({
              center: [nearest.renderLng, nearest.renderLat],
              zoom: Math.max(map.getZoom(), 7),
              duration: performanceModeRef.current ? 0 : 900,
            });
          }
        }
      }
      rafRef.current = requestAnimationFrame(tick);
    };
    rafRef.current = requestAnimationFrame(tick);
    return () => {
      if (rafRef.current != null) cancelAnimationFrame(rafRef.current);
    };
  }, []);

  return <div ref={mapNodeRef} className="absolute inset-0 bg-[#05070b]" />;
}
