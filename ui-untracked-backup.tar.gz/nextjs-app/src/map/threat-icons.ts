import type maplibregl from 'maplibre-gl';
import type { ThreatEntityType } from '@/map/threat-types';

const COLORS: Record<ThreatEntityType, string> = {
  drone: '#ff2a5f',
  missile: '#f97316',
  aviation: '#38bdf8',
  explosion: '#facc15',
  alert: '#a78bfa',
};

function drawIcon(type: ThreatEntityType): ImageData {
  const size = 64;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('Canvas unavailable');

  const color = COLORS[type];
  ctx.clearRect(0, 0, size, size);
  ctx.shadowColor = color;
  ctx.shadowBlur = 18;
  ctx.fillStyle = color;
  ctx.strokeStyle = 'rgba(255,255,255,0.88)';
  ctx.lineWidth = 3;
  ctx.translate(size / 2, size / 2);

  if (type === 'drone') {
    ctx.beginPath();
    ctx.moveTo(0, -21);
    ctx.lineTo(15, 16);
    ctx.lineTo(0, 9);
    ctx.lineTo(-15, 16);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
  } else if (type === 'missile') {
    ctx.beginPath();
    ctx.moveTo(0, -24);
    ctx.lineTo(10, 8);
    ctx.lineTo(5, 22);
    ctx.lineTo(0, 15);
    ctx.lineTo(-5, 22);
    ctx.lineTo(-10, 8);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
  } else if (type === 'aviation') {
    ctx.beginPath();
    ctx.moveTo(0, -24);
    ctx.lineTo(22, 10);
    ctx.lineTo(6, 6);
    ctx.lineTo(4, 22);
    ctx.lineTo(-4, 22);
    ctx.lineTo(-6, 6);
    ctx.lineTo(-22, 10);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
  } else {
    ctx.beginPath();
    ctx.arc(0, 0, type === 'explosion' ? 16 : 13, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
  }

  return ctx.getImageData(0, 0, size, size);
}

export function ensureThreatLayerIcons(map: maplibregl.Map) {
  (Object.keys(COLORS) as ThreatEntityType[]).forEach((type) => {
    const id = `threat-${type}`;
    if (!map.hasImage(id)) map.addImage(id, drawIcon(type), { pixelRatio: 2 });
  });
}
