import type { Marker } from '@/types';
import { normalizeThreatType, type ThreatEntity } from '@/map/threat-types';

export function markerToThreatEntity(marker: Marker | Record<string, unknown>): ThreatEntity | null {
  const lat = Number(marker.lat);
  const lng = Number(marker.lng);
  if (!Number.isFinite(lat) || !Number.isFinite(lng)) return null;

  const rawType = String(marker.threat_type || marker.type || 'alert');
  const id =
    String(marker.track_id || marker.id || '').trim() ||
    `${rawType}:${lat.toFixed(4)}:${lng.toFixed(4)}`;
  const timestamp = Number(marker.last_update_epoch || marker.created_at_epoch || Date.now());

  return {
    id,
    type: normalizeThreatType(rawType),
    lat,
    lng,
    speed: typeof marker.speed_kmh === 'number' ? marker.speed_kmh : Number(marker.speed_kmh) || undefined,
    direction:
      typeof marker.course_bearing === 'number'
        ? marker.course_bearing
        : typeof marker.ticker_bearing === 'number'
          ? marker.ticker_bearing
          : undefined,
    timestamp: timestamp > 10_000_000_000 ? timestamp : timestamp * 1000,
    status: marker.track_state === 'lost' ? 'lost' : marker.track_state === 'stale' ? 'stale' : 'active',
  };
}
