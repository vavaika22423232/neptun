import type { FeatureCollection, Point } from 'geojson';
import type { RenderEntity, ThreatEntityType } from '@/map/threat-types';

export type ThreatFeatureProperties = {
  id: string;
  type: ThreatEntityType;
  bearing: number;
  speed: number;
  status: string;
  opacity: number;
};

export type ThreatFeatureCollection = FeatureCollection<Point, ThreatFeatureProperties>;

const TYPE_PRIORITY: Record<ThreatEntityType, number> = {
  explosion: 5,
  missile: 4,
  aviation: 3,
  drone: 2,
  alert: 1,
};

export function entitiesToFeatureCollection(
  entities: Iterable<RenderEntity>,
  layers: Record<ThreatEntityType, boolean>,
): ThreatFeatureCollection {
  const features: ThreatFeatureCollection['features'] = [];
  for (const entity of entities) {
    if (!layers[entity.type]) continue;
    features.push({
      type: 'Feature',
      id: entity.id,
      geometry: {
        type: 'Point',
        coordinates: [entity.renderLng, entity.renderLat],
      },
      properties: {
        id: entity.id,
        type: entity.type,
        bearing: entity.direction ?? 0,
        speed: entity.speed ?? 0,
        status: entity.status,
        opacity: entity.status === 'stale' ? 0.55 : 1,
      },
    });
  }
  features.sort((a, b) => TYPE_PRIORITY[a.properties.type] - TYPE_PRIORITY[b.properties.type]);
  return { type: 'FeatureCollection', features };
}
