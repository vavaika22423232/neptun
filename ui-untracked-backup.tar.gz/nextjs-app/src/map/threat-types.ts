export type ThreatEntityType = 'drone' | 'missile' | 'aviation' | 'explosion' | 'alert';

export type ThreatEntityStatus = 'active' | 'stale' | 'lost' | 'cleared';

export interface ThreatEntity {
  id: string;
  type: ThreatEntityType;
  lat: number;
  lng: number;
  speed?: number;
  direction?: number;
  timestamp: number;
  status: ThreatEntityStatus;
}

export type ThreatEntityUpdate =
  | { type: 'add'; entity: ThreatEntity }
  | { type: 'update'; entity: Partial<ThreatEntity> & { id: string } }
  | { type: 'remove'; id: string };

export interface RenderEntity extends ThreatEntity {
  renderLat: number;
  renderLng: number;
  targetLat: number;
  targetLng: number;
  fromLat: number;
  fromLng: number;
  animationStartedAt: number;
  animationDurationMs: number;
}

export const THREAT_ENTITY_TYPES: ThreatEntityType[] = [
  'drone',
  'missile',
  'aviation',
  'explosion',
  'alert',
];

export function normalizeThreatType(input: string | undefined): ThreatEntityType {
  const value = (input || '').toLowerCase();
  if (value === 'shahed' || value === 'uav' || value === 'drone' || value === 'fpv') return 'drone';
  if (value === 'raketa' || value === 'missile' || value === 'ballistic' || value === 'launch') return 'missile';
  if (value === 'avia' || value === 'aviation' || value === 'kab') return 'aviation';
  if (value === 'explosion') return 'explosion';
  return 'alert';
}
