import type { StyleSpecification } from 'maplibre-gl';

const MAPTILER_KEY = process.env.NEXT_PUBLIC_MAPTILER_KEY;

export function buildThreatMapStyle(): StyleSpecification {
  if (MAPTILER_KEY) {
    return {
      version: 8,
      glyphs: `https://api.maptiler.com/fonts/{fontstack}/{range}.pbf?key=${MAPTILER_KEY}`,
      sources: {
        basemap: {
          type: 'raster',
          tiles: [`https://api.maptiler.com/maps/dataviz-dark/256/{z}/{x}/{y}.png?key=${MAPTILER_KEY}`],
          tileSize: 256,
          attribution: '© MapTiler © OpenStreetMap contributors',
        },
      },
      layers: [{ id: 'basemap', type: 'raster', source: 'basemap' }],
    };
  }

  return {
    version: 8,
    glyphs: 'https://demotiles.maplibre.org/font/{fontstack}/{range}.pbf',
    sources: {
      basemap: {
        type: 'raster',
        tiles: ['https://tile.openstreetmap.org/{z}/{x}/{y}.png'],
        tileSize: 256,
        attribution: '© OpenStreetMap contributors',
      },
    },
    layers: [
      {
        id: 'basemap',
        type: 'raster',
        source: 'basemap',
        paint: {
          'raster-brightness-min': 0.02,
          'raster-brightness-max': 0.28,
          'raster-saturation': -0.8,
          'raster-contrast': 0.25,
        },
      },
    ],
  };
}
