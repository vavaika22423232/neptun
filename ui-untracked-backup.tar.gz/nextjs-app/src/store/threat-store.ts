import { create } from 'zustand';
import type { RenderEntity, ThreatEntity, ThreatEntityType, ThreatEntityUpdate } from '@/map/threat-types';

type LayerVisibility = Record<ThreatEntityType, boolean>;

interface ThreatStoreState {
  entities: Map<string, RenderEntity>;
  layers: LayerVisibility;
  focusMode: boolean;
  performanceMode: boolean;
  connected: boolean;
  lastEventAt: number | null;
  setConnected: (connected: boolean) => void;
  setPerformanceMode: (enabled: boolean) => void;
  setFocusMode: (enabled: boolean) => void;
  toggleLayer: (type: ThreatEntityType) => void;
  applyEvent: (event: ThreatEntityUpdate) => void;
  replaceSnapshot: (entities: ThreatEntity[]) => void;
}

const DEFAULT_LAYERS: LayerVisibility = {
  drone: true,
  missile: true,
  aviation: true,
  explosion: true,
  alert: true,
};

const ANIMATION_DURATION_MS = 1400;
const ENTITY_POOL_MAX = 2000;
const entityPool: RenderEntity[] = [];

function nowMs() {
  return typeof performance !== 'undefined' ? performance.now() : Date.now();
}

function toRenderEntity(entity: ThreatEntity, previous?: RenderEntity): RenderEntity {
  const startedAt = nowMs();
  const target = previous ?? entityPool.pop();
  const renderEntity = target ?? ({} as RenderEntity);
  renderEntity.id = entity.id;
  renderEntity.type = entity.type;
  renderEntity.lat = entity.lat;
  renderEntity.lng = entity.lng;
  renderEntity.speed = entity.speed;
  renderEntity.direction = entity.direction;
  renderEntity.timestamp = entity.timestamp;
  renderEntity.status = entity.status;
  renderEntity.renderLat = previous?.renderLat ?? entity.lat;
  renderEntity.renderLng = previous?.renderLng ?? entity.lng;
  renderEntity.fromLat = previous?.renderLat ?? entity.lat;
  renderEntity.fromLng = previous?.renderLng ?? entity.lng;
  renderEntity.targetLat = entity.lat;
  renderEntity.targetLng = entity.lng;
  renderEntity.animationStartedAt = startedAt;
  renderEntity.animationDurationMs = ANIMATION_DURATION_MS;
  return renderEntity;
}

function releaseEntity(entity: RenderEntity | undefined) {
  if (!entity || entityPool.length >= ENTITY_POOL_MAX) return;
  entityPool.push(entity);
}

export const useThreatStore = create<ThreatStoreState>((set) => ({
  entities: new Map(),
  layers: DEFAULT_LAYERS,
  focusMode: false,
  performanceMode: false,
  connected: false,
  lastEventAt: null,
  setConnected: (connected) => set({ connected }),
  setPerformanceMode: (enabled) => set({ performanceMode: enabled }),
  setFocusMode: (enabled) => set({ focusMode: enabled }),
  toggleLayer: (type) =>
    set((state) => ({
      layers: { ...state.layers, [type]: !state.layers[type] },
    })),
  replaceSnapshot: (entities) =>
    set((state) => {
      const next = new Map<string, RenderEntity>();
      for (const entity of state.entities.values()) releaseEntity(entity);
      for (const entity of entities) {
        next.set(entity.id, toRenderEntity(entity));
      }
      return { entities: next, lastEventAt: Date.now() };
    }),
  applyEvent: (event) =>
    set((state) => {
      const next = new Map(state.entities);
      if (event.type === 'remove') {
        releaseEntity(next.get(event.id));
        next.delete(event.id);
      } else if (event.type === 'add') {
        next.set(event.entity.id, toRenderEntity(event.entity, next.get(event.entity.id)));
      } else {
        const current = next.get(event.entity.id);
        if (current) {
          const merged: ThreatEntity = {
            ...current,
            ...event.entity,
            lat: event.entity.lat ?? current.lat,
            lng: event.entity.lng ?? current.lng,
            timestamp: event.entity.timestamp ?? Date.now(),
          };
          next.set(merged.id, toRenderEntity(merged, current));
        }
      }
      return { entities: next, lastEventAt: Date.now() };
    }),
}));
