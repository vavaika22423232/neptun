import type { Metadata } from 'next';
import Link from 'next/link';
import Footer from '@/components/Footer';

export const metadata: Metadata = {
  title: 'Як читати карту загроз NEPTUN — тривоги, маркери, траєкторії',
  description:
    'Простий гайд: що означають червоні зони тривог, маркери цілей, напрямок руху та оновлення даних. Як не плутати прогноз і факт.',
  keywords:
    'як читати карту тривог, карта загроз пояснення, neptun карта інструкція, мапа тривог як користуватися',
  alternates: { canonical: 'https://neptun.in.ua/blog/jak-chytaty-kartu-neptun' },
  openGraph: {
    type: 'article',
    url: 'https://neptun.in.ua/blog/jak-chytaty-kartu-neptun',
    title: 'Як читати карту загроз NEPTUN',
    description: 'Тривоги, маркери та траєкторії — що означають на карті.',
    images: [{ url: 'https://neptun.in.ua/api/og', width: 1200, height: 630 }],
    siteName: 'NEPTUN',
    locale: 'uk_UA',
  },
};

export default function Article() {
  const jsonLd = {
    '@context': 'https://schema.org',
    '@type': 'BlogPosting',
    headline: 'Як читати карту загроз NEPTUN',
    url: 'https://neptun.in.ua/blog/jak-chytaty-kartu-neptun',
    datePublished: '2026-04-23',
    dateModified: '2026-04-23',
    author: { '@type': 'Organization', name: 'NEPTUN', url: 'https://neptun.in.ua' },
    publisher: { '@type': 'Organization', name: 'NEPTUN', url: 'https://neptun.in.ua' },
    inLanguage: 'uk',
    mainEntityOfPage: 'https://neptun.in.ua/blog/jak-chytaty-kartu-neptun',
    breadcrumb: {
      '@type': 'BreadcrumbList',
      itemListElement: [
        { '@type': 'ListItem', position: 1, name: 'Головна', item: 'https://neptun.in.ua/' },
        { '@type': 'ListItem', position: 2, name: 'Блог', item: 'https://neptun.in.ua/blog' },
        { '@type': 'ListItem', position: 3, name: 'Як читати карту', item: 'https://neptun.in.ua/blog/jak-chytaty-kartu-neptun' },
      ],
    },
  };

  return (
    <div className="min-h-screen bg-[var(--surface-dim)] text-white/80 p-6 max-w-3xl mx-auto">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />

      <nav className="text-sm text-white/40 mb-6 flex items-center gap-2">
        <Link href="/" className="text-blue-400 hover:text-blue-300">Головна</Link>
        <span>/</span>
        <Link href="/blog" className="text-blue-400 hover:text-blue-300">Блог</Link>
        <span>/</span>
        <span className="text-white/60">Як читати карту</span>
      </nav>

      <article>
        <div className="text-xs text-white/40 mb-3">
          <time dateTime="2026-04-23">23 квітня 2026</time> · 5 хв читання
        </div>

        <h1 className="text-3xl font-bold text-white mb-6">Як читати карту загроз NEPTUN</h1>

        <div className="space-y-4 text-[15px] leading-relaxed">
          <p>
            Карта NEPTUN поєднує <strong className="text-white">повітряні тривоги</strong> по областях і{' '}
            <strong className="text-white">маркери подій</strong> із відкритих джерел. Нижче — як не плутати зони, точки та напрямки.
          </p>

          <h2 className="text-xl font-semibold text-white mt-8">Зона тривоги</h2>
          <p>
            Закрашена область означає, що за даними сервісу в цьому регіоні діє або нещодавно діяла повітряна тривога. Після відбою зона зникає або оновлюється —
            невелика затримка відображення можлива через мережу або оновлення стрічки даних.
          </p>

          <h2 className="text-xl font-semibold text-white mt-8">Маркер цілі</h2>
          <p>
            Іконка на карті — це <strong className="text-white">узагальнена подія</strong> (БПЛА, ракета, тощо), прив’язана до координат або регіону з тексту повідомлення.
            Точка не завжди означає «тут влучання»; часто це напрямок, район або орієнтир із каналу.
          </p>

          <h2 className="text-xl font-semibold text-white mt-8">Траєкторія та стрілка</h2>
          <p>
            Лінія або орієнтація можуть показувати <strong className="text-white">ймовірний напрямок</strong> на основі кількох повідомлень. Це допоміжна візуалізація, не наказ ППО.
            Якщо лінія зникла — дані могли оновитися або об’єднатися з іншим треком.
          </p>

          <h2 className="text-xl font-semibold text-white mt-8">Оновлення та «онлайн»</h2>
          <p>
            Сервіс намагається оновлювати зображення швидко; цифра «онлайн» у інтерфейсі відображає приблизну кількість активних сесій, а не офіційний перепис населення.
            Якщо бачите попередження про збережені дані — з’єднання з сервером тимчасово обмежене, варто оновити сторінку пізніше.
          </p>

          <p className="border border-white/10 rounded-xl p-4 bg-white/5 mt-6">
            Детальніше про джерела та обмеження точності — на сторінці{' '}
            <Link href="/pro-kartu-dzherela" className="text-blue-400 hover:text-blue-300">«Джерела й точність»</Link>.
          </p>

          <p>
            Повернутися на{' '}
            <Link href="/" className="text-blue-400 hover:text-blue-300">головну карту</Link>
            {' '}або переглянути{' '}
            <Link href="/tryvoga-zaraz" className="text-blue-400 hover:text-blue-300">тривогу зараз</Link>.
          </p>
        </div>
      </article>

      <Footer />
    </div>
  );
}
