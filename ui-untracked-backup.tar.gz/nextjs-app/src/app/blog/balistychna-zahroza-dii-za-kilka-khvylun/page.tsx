import type { Metadata } from 'next';
import Link from 'next/link';
import Footer from '@/components/Footer';

export const metadata: Metadata = {
  title: 'Балістична загроза на карті: що робити за хвилини | NEPTUN',
  description:
    'Чому банер балістики — сигнал діяти миттєво, як поводитись у сходовій клітці та приміщенні, що не робити з вікнами й телефоном.',
  keywords:
    'балістична ракета що робити, банер балістика neptun, укриття балістика, карта тривог балістика',
  alternates: { canonical: 'https://neptun.in.ua/blog/balistychna-zahroza-dii-za-kilka-khvylun' },
  openGraph: {
    type: 'article',
    url: 'https://neptun.in.ua/blog/balistychna-zahroza-dii-za-kilka-khvylun',
    title: 'Балістична загроза: дії за хвилини',
    description: 'Короткий протокол, коли на карті з’явилась балістична загроза.',
    images: [{ url: 'https://neptun.in.ua/api/og', width: 1200, height: 630 }],
    siteName: 'NEPTUN',
    locale: 'uk_UA',
  },
};

export default function Article() {
  const jsonLd = {
    '@context': 'https://schema.org',
    '@type': 'BlogPosting',
    headline: 'Балістична загроза: що робити, коли на карті з’явився банер',
    url: 'https://neptun.in.ua/blog/balistychna-zahroza-dii-za-kilka-khvylun',
    datePublished: '2026-04-23',
    dateModified: '2026-04-23',
    author: { '@type': 'Organization', name: 'NEPTUN', url: 'https://neptun.in.ua' },
    publisher: { '@type': 'Organization', name: 'NEPTUN', url: 'https://neptun.in.ua' },
    inLanguage: 'uk',
    mainEntityOfPage: 'https://neptun.in.ua/blog/balistychna-zahroza-dii-za-kilka-khvylun',
  };

  return (
    <div className="min-h-screen bg-[var(--surface-dim)] text-white/80 p-6 max-w-3xl mx-auto">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />

      <nav className="text-sm text-white/40 mb-6 flex items-center gap-2 flex-wrap">
        <Link href="/" className="text-blue-400 hover:text-blue-300">Головна</Link>
        <span>/</span>
        <Link href="/blog" className="text-blue-400 hover:text-blue-300">Блог</Link>
        <span>/</span>
        <span className="text-white/60">Балістична загроза</span>
      </nav>

      <article>
        <div className="text-xs text-white/40 mb-3">
          <time dateTime="2026-04-23">23 квітня 2026</time> · 5 хв читання
        </div>

        <h1 className="text-3xl font-bold text-white mb-6">
          Балістична загроза: що робити, коли на карті з’явився банер
        </h1>

        <div className="space-y-4 text-[15px] leading-relaxed">
          <p>
            На <Link href="/" className="text-blue-400 hover:text-blue-300">карті NEPTUN</Link> балістика позначається окремо:
            часу на рух «подивитися з вікна» майже немає. Нижче — мінімальний протокол, який відповідає рекомендаціям
            цивільного захисту (укриття, стіни, відстань від скла).
          </p>

          <h2 className="text-xl font-semibold text-white mt-8">Миттєво: укриття або найбезпечніша кімната</h2>
          <p>
            Якщо ви вдома — дві стіни від вулиці, без вікон, під підлогою сусідів. Якщо в дорозі — низько, біля бордюру,
            подалі від автобусних зупинок із склом. Ліфт не використовуйте.
          </p>

          <h2 className="text-xl font-semibold text-white mt-8">Телефон і світло</h2>
          <p>
            Вимкніть яскравий екран, не знімайте відео з вікна — це відволікає вас і оточуючих. Дзвінки обмежте короткими
            повідомленнями «я в укритті», щоб не перевантажувати мережу.
          </p>

          <h2 className="text-xl font-semibold text-white mt-8">Після «відбою»</h2>
          <p>
            Дочекайтеся офіційного відбою по вашому регіону. Виходьте сходами, огляньте периметр на уламки скла.
            Якщо чуєте вибух близько — залишайтеся в укритті до уточнення від ДСНС/ОВА.
          </p>

          <p className="pt-4 border-t border-white/10 text-white/60 text-sm">
            Деталі про типи ракет і час польоту — у{' '}
            <Link href="/blog/typy-povitryanykh-zahroz" className="text-blue-400 hover:text-blue-300">«Типах повітряних загроз»</Link>.
            Загальний алгоритм тривоги — у{' '}
            <Link href="/blog/shcho-robyty-pid-chas-tryvohy" className="text-blue-400 hover:text-blue-300">покроковій інструкції</Link>.
          </p>
        </div>
      </article>

      <Footer />
    </div>
  );
}
