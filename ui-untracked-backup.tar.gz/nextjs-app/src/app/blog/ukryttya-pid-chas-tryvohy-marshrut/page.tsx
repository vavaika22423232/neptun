import type { Metadata } from 'next';
import Link from 'next/link';
import Footer from '@/components/Footer';

export const metadata: Metadata = {
  title: 'Укриття та маршрут під час тривоги — дії за хвилини | NEPTUN',
  description:
    'Як швидко дістатися до укриття, що покласти в «тривожну торбу», як узгодити діти/тварини та чому не варто їхати навпростець через місто.',
  keywords:
    'укриття під час тривоги, маршрут тривога, тривожна торба, карта тривог безпека',
  alternates: { canonical: 'https://neptun.in.ua/blog/ukryttya-pid-chas-tryvohy-marshrut' },
  openGraph: {
    type: 'article',
    url: 'https://neptun.in.ua/blog/ukryttya-pid-chas-tryvohy-marshrut',
    title: 'Укриття та маршрут під час тривоги',
    description: 'Короткий чеклист дій, поки карта показує активну загрозу.',
    images: [{ url: 'https://neptun.in.ua/api/og', width: 1200, height: 630 }],
    siteName: 'NEPTUN',
    locale: 'uk_UA',
  },
};

export default function Article() {
  const jsonLd = {
    '@context': 'https://schema.org',
    '@type': 'BlogPosting',
    headline: 'Укриття та маршрут під час тривоги: що встигнути за хвилини',
    url: 'https://neptun.in.ua/blog/ukryttya-pid-chas-tryvohy-marshrut',
    datePublished: '2026-04-23',
    dateModified: '2026-04-23',
    author: { '@type': 'Organization', name: 'NEPTUN', url: 'https://neptun.in.ua' },
    publisher: { '@type': 'Organization', name: 'NEPTUN', url: 'https://neptun.in.ua' },
    inLanguage: 'uk',
    mainEntityOfPage: 'https://neptun.in.ua/blog/ukryttya-pid-chas-tryvohy-marshrut',
  };

  return (
    <div className="min-h-screen bg-[var(--surface-dim)] text-white/80 p-6 max-w-3xl mx-auto">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />

      <nav className="text-sm text-white/40 mb-6 flex items-center gap-2 flex-wrap">
        <Link href="/" className="text-blue-400 hover:text-blue-300">Головна</Link>
        <span>/</span>
        <Link href="/blog" className="text-blue-400 hover:text-blue-300">Блог</Link>
        <span>/</span>
        <span className="text-white/60">Укриття й маршрут</span>
      </nav>

      <article>
        <div className="text-xs text-white/40 mb-3">
          <time dateTime="2026-04-23">23 квітня 2026</time> · 7 хв читання
        </div>

        <h1 className="text-3xl font-bold text-white mb-6">
          Укриття та маршрут під час тривоги: що встигнути за хвилини
        </h1>

        <div className="space-y-4 text-[15px] leading-relaxed">
          <p>
            Коли на <Link href="/" className="text-blue-400 hover:text-blue-300">карті NEPTUN</Link> горить тривога
            або з’являється маркер загрози, час працює проти вас. Нижче — послідовність, яку простіше виконувати автоматично,
            якщо ви проговорили її з родиною заздалегідь.
          </p>

          <h2 className="text-xl font-semibold text-white mt-8">1. Найближче укриття, а не «ідеальне»</h2>
          <p>
            Обирайте точку, до якої реально встигнете за 2–3 хвилини пішки. Підвал будинку, станція метро, укриття з мапи
            вашої громади — те, що ви вже відмічали на прогулянці, а не нове місце з навігатора.
          </p>

          <h2 className="text-xl font-semibold text-white mt-8">2. Маршрут без зайвих перехресть</h2>
          <p>
            Уникайте довгих відкритих ділянок і пробок біля мостів/виїздів. Якщо їдете авто — одразу паркуйтеся біля входу
            в укриття, не шукайте «кращого» місця на парковці торгового центру.
          </p>

          <h2 className="text-xl font-semibold text-white mt-8">3. Тривожна торба</h2>
          <p>
            Вода, ліки, документи в zip-пакеті, павербанк, ліхтарик, теплий шар одягу для дітей. Тваринам — переноска
            і намордник/повідець, якщо вимагає правило укриття.
          </p>

          <h2 className="text-xl font-semibold text-white mt-8">4. Діти та літні люди</h2>
          <p>
            Один дорослий відповідає за дитину, другий — за документи/телефон. Домовтеся про слово-код, якщо розділитеся
            сходами. Телефон тримайте без «зайвих» відео — економте батарею й канал.
          </p>

          <p className="pt-4 border-t border-white/10 text-white/60 text-sm">
            Розширена покрокова інструкція — у статті{' '}
            <Link href="/blog/shcho-robyty-pid-chas-tryvohy" className="text-blue-400 hover:text-blue-300">«Що робити під час повітряної тривоги»</Link>.
            Типи загроз і час реакції — у матеріалі{' '}
            <Link href="/blog/typy-povitryanykh-zahroz" className="text-blue-400 hover:text-blue-300">«Типи повітряних загроз»</Link>.
          </p>
        </div>
      </article>

      <Footer />
    </div>
  );
}
