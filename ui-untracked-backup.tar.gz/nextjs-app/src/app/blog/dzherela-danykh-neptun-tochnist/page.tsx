import type { Metadata } from 'next';
import Link from 'next/link';
import Footer from '@/components/Footer';

export const metadata: Metadata = {
  title: 'Звідки дані NEPTUN і наскільки точна карта тривог | NEPTUN',
  description:
    'Які джерела використовує NEPTUN, чому з’являється затримка 5–10 с, чим сервіс відрізняється від державної сирени та як читати маркери відповідально.',
  keywords:
    'джерела карти тривог, точність neptun, telegram ова, моніторинг тривог, карта шахедів джерела',
  alternates: { canonical: 'https://neptun.in.ua/blog/dzherela-danykh-neptun-tochnist' },
  openGraph: {
    type: 'article',
    url: 'https://neptun.in.ua/blog/dzherela-danykh-neptun-tochnist',
    title: 'Звідки дані NEPTUN і наскільки точна карта',
    description: 'Прозорість джерел, затримки та відмінність від офіційного оповіщення.',
    images: [{ url: 'https://neptun.in.ua/api/og', width: 1200, height: 630 }],
    siteName: 'NEPTUN',
    locale: 'uk_UA',
  },
};

export default function Article() {
  const jsonLd = {
    '@context': 'https://schema.org',
    '@type': 'BlogPosting',
    headline: 'Звідки беруться дані на карті NEPTUN і наскільки вони точні',
    url: 'https://neptun.in.ua/blog/dzherela-danykh-neptun-tochnist',
    datePublished: '2026-04-23',
    dateModified: '2026-04-23',
    author: { '@type': 'Organization', name: 'NEPTUN', url: 'https://neptun.in.ua' },
    publisher: { '@type': 'Organization', name: 'NEPTUN', url: 'https://neptun.in.ua' },
    inLanguage: 'uk',
    mainEntityOfPage: 'https://neptun.in.ua/blog/dzherela-danykh-neptun-tochnist',
  };

  return (
    <div className="min-h-screen bg-[var(--surface-dim)] text-white/80 p-6 max-w-3xl mx-auto">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />

      <nav className="text-sm text-white/40 mb-6 flex items-center gap-2 flex-wrap">
        <Link href="/" className="text-blue-400 hover:text-blue-300">Головна</Link>
        <span>/</span>
        <Link href="/blog" className="text-blue-400 hover:text-blue-300">Блог</Link>
        <span>/</span>
        <span className="text-white/60">Джерела й точність</span>
      </nav>

      <article>
        <div className="text-xs text-white/40 mb-3">
          <time dateTime="2026-04-23">23 квітня 2026</time> · 6 хв читання
        </div>

        <h1 className="text-3xl font-bold text-white mb-6">
          Звідки беруться дані на карті NEPTUN і наскільки вони точні
        </h1>

        <div className="space-y-4 text-[15px] leading-relaxed">
          <p>
            NEPTUN показує <Link href="/karta-tryvoh" className="text-blue-400 hover:text-blue-300">карту тривог</Link>,{' '}
            <Link href="/karta-shahediv" className="text-blue-400 hover:text-blue-300">шахеди</Link> та ракетні загрози в одному інтерфейсі.
            Нижче — коротко, що саме потрапляє на карту і які обмеження варто пам’ятати.
          </p>

          <h2 className="text-xl font-semibold text-white mt-8">Що ми моніторимо</h2>
          <p>
            Система зчитує публічні повідомлення з каналів обласних військових адміністрацій, Повітряних сил
            та перевірених моніторингових стрічок. Кожне повідомлення проходить класифікацію: тип загрози, регіон,
            напрямок руху, за потреби — геоприв’язка для маркера на карті.
          </p>

          <h2 className="text-xl font-semibold text-white mt-8">Чому буває затримка 5–10 секунд</h2>
          <p>
            Подія з’являється на карті після того, як текст опубліковано у джерелі й оброблено пайплайном.
            Типова затримка — кілька секунд; інколи довше, якщо навантаження на канал або неоднозначний текст.
            Це не «запізнення радару», а час доставки та нормалізації даних.
          </p>

          <h2 className="text-xl font-semibold text-white mt-8">NEPTUN і державна сирена</h2>
          <p>
            Додаток «Повітряна тривога» та офіційні канали ОВА залишаються еталоном саме для сигналу «тривога / відбій».
            NEPTUN дає розширений моніторинг відкритих текстів (шахеди, маршрути, тип боєголовки) і може показувати
            контекст раніше або детальніше, ніж коротке push-повідомлення — але рішення про укриття приймаєте ви,
            опираючись на офіційні інструкції цивільного захисту.
          </p>

          <h2 className="text-xl font-semibold text-white mt-8">Як читати карту відповідально</h2>
          <ul className="list-disc pl-6 space-y-2">
            <li>Перевіряйте статус тривоги по області та сусідах.</li>
            <li>Маркер загрози — модель на основі тексту, не «відео з дрона».</li>
            <li>Якщо дані суперечать одне одному, пріоритет — офіційні канали вашого регіону.</li>
          </ul>

          <p className="pt-4 border-t border-white/10">
            Детальніше про методологію й обмеження — на сторінці{' '}
            <Link href="/pro-kartu-dzherela" className="text-blue-400 hover:text-blue-300">«Про карту та джерела»</Link>.
            Як розшифровувати інтерфейс — у гайді{' '}
            <Link href="/blog/jak-chytaty-kartu-neptun" className="text-blue-400 hover:text-blue-300">«Як читати карту NEPTUN»</Link>.
          </p>
        </div>
      </article>

      <Footer />
    </div>
  );
}
