import RealtimeMapClient from './RealtimeMapClient';

export const metadata = {
  title: 'Realtime Threat Map | Neptun',
  description: 'High-performance MapLibre realtime threat map.',
};

export default function RealtimeMapPage() {
  return <RealtimeMapClient />;
}
