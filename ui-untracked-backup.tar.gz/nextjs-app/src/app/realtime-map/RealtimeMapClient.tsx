'use client';

import dynamic from 'next/dynamic';
import { Activity, Gauge, Layers3, LocateFixed, RadioTower } from 'lucide-react';
import { useEffect, useMemo, useState } from 'react';
import { useThreatWebSocket } from '@/hooks/useThreatWebSocket';
import { THREAT_ENTITY_TYPES, type ThreatEntityType } from '@/map/threat-types';
import { useThreatStore } from '@/store/threat-store';

const ThreatMap = dynamic(() => import('@/map/ThreatMap'), {
  ssr: false,
  loading: () => <div className="absolute inset-0 bg-[#05070b]" />,
});

const LABELS: Record<ThreatEntityType, string> = {
  drone: 'Drones',
  missile: 'Missiles',
  aviation: 'Aviation',
  explosion: 'Explosions',
  alert: 'Alerts',
};

function GlassPanel({ children, className = '' }: { children: React.ReactNode; className?: string }) {
  return (
    <div className={`rounded-2xl border border-white/10 bg-black/35 p-4 shadow-2xl shadow-black/40 backdrop-blur-xl ${className}`}>
      {children}
    </div>
  );
}

function ToggleButton({
  active,
  children,
  onClick,
}: {
  active: boolean;
  children: React.ReactNode;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`rounded-xl border px-3 py-2 text-left text-xs font-medium transition ${
        active
          ? 'border-[#ff2a5f]/50 bg-[#ff2a5f]/15 text-white'
          : 'border-white/10 bg-white/[0.04] text-white/45 hover:text-white/75'
      }`}
    >
      {children}
    </button>
  );
}

export default function RealtimeMapClient() {
  useThreatWebSocket();
  const connected = useThreatStore((s) => s.connected);
  const entities = useThreatStore((s) => s.entities);
  const layers = useThreatStore((s) => s.layers);
  const focusMode = useThreatStore((s) => s.focusMode);
  const performanceMode = useThreatStore((s) => s.performanceMode);
  const lastEventAt = useThreatStore((s) => s.lastEventAt);
  const toggleLayer = useThreatStore((s) => s.toggleLayer);
  const setFocusMode = useThreatStore((s) => s.setFocusMode);
  const setPerformanceMode = useThreatStore((s) => s.setPerformanceMode);
  const [clock, setClock] = useState(() => Date.now());

  useEffect(() => {
    const id = window.setInterval(() => setClock(Date.now()), 1000);
    return () => window.clearInterval(id);
  }, []);

  const counts = useMemo(() => {
    const next: Record<ThreatEntityType, number> = {
      drone: 0,
      missile: 0,
      aviation: 0,
      explosion: 0,
      alert: 0,
    };
    for (const entity of entities.values()) next[entity.type] += 1;
    return next;
  }, [entities]);

  return (
    <main className="relative h-screen w-full overflow-hidden bg-[#05070b] text-white">
      <ThreatMap />

      <div className="pointer-events-none absolute inset-x-0 top-0 z-10 flex items-start justify-between gap-4 p-4">
        <GlassPanel className="pointer-events-auto w-[320px] max-w-[calc(100vw-2rem)]">
          <div className="mb-4 flex items-center justify-between">
            <div>
              <div className="text-[10px] uppercase tracking-[0.32em] text-white/35">Neptun Realtime</div>
              <h1 className="mt-1 text-lg font-semibold tracking-tight">Threat Map</h1>
            </div>
            <div className={`flex items-center gap-2 rounded-full px-2.5 py-1 text-[11px] ${connected ? 'bg-emerald-500/15 text-emerald-300' : 'bg-red-500/15 text-red-300'}`}>
              <RadioTower className="h-3.5 w-3.5" />
              {connected ? 'Live' : 'Offline'}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2">
            {THREAT_ENTITY_TYPES.map((type) => (
              <ToggleButton key={type} active={layers[type]} onClick={() => toggleLayer(type)}>
                <span className="flex items-center justify-between gap-2">
                  <span>{LABELS[type]}</span>
                  <span className="text-white/35">{counts[type]}</span>
                </span>
              </ToggleButton>
            ))}
          </div>
        </GlassPanel>

        <GlassPanel className="pointer-events-auto hidden w-[260px] md:block">
          <div className="mb-3 flex items-center gap-2 text-sm font-semibold">
            <Activity className="h-4 w-4 text-[#ff2a5f]" />
            Status
          </div>
          <div className="space-y-2 text-xs text-white/55">
            <div className="flex justify-between"><span>Entities</span><span className="text-white">{entities.size}</span></div>
            <div className="flex justify-between"><span>Last event</span><span className="text-white">{lastEventAt ? `${Math.max(0, Math.round((clock - lastEventAt) / 1000))}s` : 'none'}</span></div>
            <div className="flex justify-between"><span>Rendering</span><span className="text-white">MapLibre GL</span></div>
          </div>
        </GlassPanel>
      </div>

      <div className="pointer-events-none absolute inset-x-0 bottom-0 z-10 flex justify-center p-4">
        <GlassPanel className="pointer-events-auto flex gap-2">
          <ToggleButton active={focusMode} onClick={() => setFocusMode(!focusMode)}>
            <span className="flex items-center gap-2"><LocateFixed className="h-3.5 w-3.5" /> Focus</span>
          </ToggleButton>
          <ToggleButton active={performanceMode} onClick={() => setPerformanceMode(!performanceMode)}>
            <span className="flex items-center gap-2"><Gauge className="h-3.5 w-3.5" /> Performance</span>
          </ToggleButton>
          <div className="hidden items-center gap-2 rounded-xl border border-white/10 bg-white/[0.04] px-3 py-2 text-xs text-white/45 sm:flex">
            <Layers3 className="h-3.5 w-3.5" />
            Diff updates only
          </div>
        </GlassPanel>
      </div>
    </main>
  );
}
