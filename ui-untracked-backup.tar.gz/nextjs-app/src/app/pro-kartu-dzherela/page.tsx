import type { Metadata } from 'next';
import Link from 'next/link';
import Footer from '@/components/Footer';

export const metadata: Metadata = {
  title: 'Джерела даних і точність карти NEPTUN — повітряні тривоги та цілі',
  description:
    'Звідки NEPTUN бере дані про повітряні тривоги та цілі, як працює перевірка координат, чому маркер може зникати або зміщуватися. Сервіс не є офіційною системою оповіщення.',
  keywords:
    'neptun джерела даних, точність карти тривог, як працює карта тривог, повітряна тривога карта пояснення',
  alternates: {
    canonical: 'https://neptun.in.ua/pro-kartu-dzherela',
  },
  openGraph: {
    type: 'website',
    url: 'https://neptun.in.ua/pro-kartu-dzherela',
    title: 'Джерела й точність карти NEPTUN',
    description:
      'Прозорість щодо даних на карті: тривоги, цілі, обмеження точності. Не офіційна система оповіщення.',
    images: [{ url: 'https://neptun.in.ua/api/og', width: 1200, height: 630, alt: 'NEPTUN — джерела даних' }],
    siteName: 'NEPTUN Карта тривог',
    locale: 'uk_UA',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Джерела й точність карти NEPTUN',
    description: 'Як формуються дані на карті тривог і цілей, які є обмеження.',
    images: ['https://neptun.in.ua/api/og'],
  },
};

const pageDescription =
  'Звідки NEPTUN бере дані про повітряні тривоги та цілі, як працює перевірка координат, чому маркер може зникати або зміщуватися. Сервіс не є офіційною системою оповіщення.';

export default function ProKartuDzherelaPage() {
  const faqItems = [
    {
      q: 'Чи NEPTUN є офіційною системою оповіщення про тривоги?',
      a: 'Ні. Офіційне оповіщення здійснюють уповноважені органи. NEPTUN — інформаційний сервіс на основі відкритих джерел і автоматичної обробки. Завжди керуйтеся сиренами, повідомленнями ДСНС/ОВА та офіційними каналами.',
    },
    {
      q: 'Звідки беруться дані на карті?',
      a: 'Потік повідомлень з відкритих каналів (зокрема Telegram ОВА, військових і волонтерських стрічок), які обробляються автоматично: визначається тип загрози, напрямок, геоприв’язка. Тривоги по регіонах синхронізуються з загальнодоступними джерелами стану тривог.',
    },
    {
      q: 'Чому маркер цілі зник або стрибнув?',
      a: 'Маркери з’єднуються в треки, коригуються за новими повідомленнями, фільтруються за швидкістю та правдоподібністю. При низькій впевненості або суперечливих координатах точка може бути прихована або зміщена до узгодженого з текстом регіону.',
    },
    {
      q: 'Чи можна покладатися на карту для укриття?',
      a: 'Карта допомагає орієнтуватися в ситуації, але не замінює офіційні інструкції. Укриття, маршрути евакуації та рішення про безпеку приймайте за місцевими правилами і офіційними попередженнями.',
    },
    {
      q: 'Де технічні деталі для розробників і партнерів?',
      a: 'Опис логіки публікації даних на карті та ingest є у внутрішній документації проєкту (на кшталт NEPTUN_DATA_FLOW у репозиторії). Для ЗМІ та партнерів краще посилатися на цю сторінку як на людське пояснення.',
    },
  ];

  const jsonLdWebPage = {
    '@context': 'https://schema.org',
    '@type': 'WebPage',
    name: 'Джерела даних і точність карти NEPTUN',
    url: 'https://neptun.in.ua/pro-kartu-dzherela',
    description: pageDescription,
    isPartOf: { '@type': 'WebSite', name: 'NEPTUN', url: 'https://neptun.in.ua' },
    breadcrumb: {
      '@type': 'BreadcrumbList',
      itemListElement: [
        { '@type': 'ListItem', position: 1, name: 'Головна', item: 'https://neptun.in.ua/' },
        { '@type': 'ListItem', position: 2, name: 'Джерела й точність', item: 'https://neptun.in.ua/pro-kartu-dzherela' },
      ],
    },
  };

  const jsonLdFaq = {
    '@context': 'https://schema.org',
    '@type': 'FAQPage',
    mainEntity: faqItems.map((item) => ({
      '@type': 'Question',
      name: item.q,
      acceptedAnswer: { '@type': 'Answer', text: item.a },
    })),
  };

  return (
    <div className="min-h-screen bg-[var(--surface-dim)] text-white/80 p-6 max-w-3xl mx-auto">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLdWebPage) }} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLdFaq) }} />

      <nav className="text-sm text-white/40 mb-6 flex flex-wrap items-center gap-2">
        <Link href="/" className="text-blue-400 hover:text-blue-300">
          Головна
        </Link>
        <span>/</span>
        <span className="text-white/60">Джерела й точність</span>
      </nav>

      <h1 className="text-3xl font-bold text-white mb-6">Джерела даних і точність карти NEPTUN</h1>

      <div className="space-y-4 text-[15px] leading-relaxed">
        <p>
          Ця сторінка пояснює, <strong className="text-white">як формується зображення на карті</strong> — повітряні тривоги,
          маркери загроз, траєкторії — і які <strong className="text-white">обмеження</strong> має будь-яка автоматизована система.
          Мета — прозорість для користувачів, ЗМІ та партнерів.
        </p>

        <h2 className="text-xl font-semibold text-white mt-8">Що ви бачите на карті</h2>
        <ul className="list-disc pl-6 space-y-2">
          <li>
            <strong className="text-white/90">Повітряні тривоги</strong> — стан по областях і районах у узгодженні з даними, які отримує сервіс.
          </li>
          <li>
            <strong className="text-white/90">Цілі та події</strong> — зміст відкритих повідомлень після автоматичного розбору (тип загрози, напрямок, місце).
          </li>
          <li>
            <strong className="text-white/90">Траєкторії та прогнози</strong> — можуть будуватися з послідовних спостережень і евристик; це не гарантія фактичного маршруту.
          </li>
        </ul>

        <h2 className="text-xl font-semibold text-white mt-8">Чому дані не завжди ідеальні</h2>
        <p>
          Повідомлення з каналів бувають розмитими, з помилками геокодування або узагальненнями («на Київщині»). Система намагається узгодити текст, область і координати;
          інколи коректніше показати <strong className="text-white">регіон</strong>, ніж хибну точку на мапі. Окремі типи подій (наприклад, повітряна куля проти БПЛА) можуть бути
          перекласифіковані за формулюваннями в тексті.
        </p>

        <h2 className="text-xl font-semibold text-white mt-8">NEPTUN і екосистема</h2>
        <p>
          Окрім веб-карти, є{' '}
          <Link href="/about" className="text-blue-400 hover:text-blue-300">
            мобільні застосунки
          </Link>{' '}
          та додаткові функції (сповіщення, чат для Pro тощо). Це один бренд — зручно для родини, яка хоче єдиний сервіс на телефоні й у браузері.
        </p>

        <h2 className="text-xl font-semibold text-white mt-8">Корисні посилання</h2>
        <ul className="list-disc pl-6 space-y-2">
          <li>
            <Link href="/" className="text-blue-400 hover:text-blue-300">
              Інтерактивна карта
            </Link>
          </li>
          <li>
            <Link href="/blog/porivnyannya-kart-tryvoh" className="text-blue-400 hover:text-blue-300">
              Порівняння карт тривог
            </Link>
          </li>
          <li>
            <Link href="/blog/jak-chytaty-kartu-neptun" className="text-blue-400 hover:text-blue-300">
              Як читати карту загроз
            </Link>
          </li>
          <li>
            <Link href="/faq" className="text-blue-400 hover:text-blue-300">
              FAQ
            </Link>
          </li>
        </ul>

        <h2 className="text-xl font-semibold text-white mt-8">Питання та відповіді</h2>
        <div className="space-y-6">
          {faqItems.map((item) => (
            <div key={item.q} className="border-l-2 border-[#ff2a5f]/40 pl-4">
              <h3 className="text-base font-semibold text-white mb-2">{item.q}</h3>
              <p className="text-white/70">{item.a}</p>
            </div>
          ))}
        </div>
      </div>

      <Footer />
    </div>
  );
}
