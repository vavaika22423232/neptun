'use client';

import dynamic from 'next/dynamic';
import { Suspense, memo } from 'react';
import { useSearchParams } from 'next/navigation';
import type { Alarm, FusionTrajectory, Marker } from '@/types';

const LeafletMap = dynamic(() => import('@/components/Map/MapContainer'), {
  ssr: false,
  loading: () => (
    <div className="flex h-full w-full items-center justify-center">
      <div className="animate-pulse text-[10px] tracking-widest uppercase text-white/30">Завантаження радару…</div>
    </div>
  ),
});

const MapLibreMap = dynamic(() => import('@/components/Map/MapLibreContainer'), {
  ssr: false,
  loading: () => (
    <div className="flex h-full w-full items-center justify-center">
      <div className="animate-pulse text-[10px] tracking-widest uppercase text-white/30">Завантаження радару…</div>
    </div>
  ),
});

const mapLoadingFallback = (
  <div className="flex h-full w-full items-center justify-center">
    <div className="animate-pulse text-[10px] tracking-widest uppercase text-white/30">Завантаження радару…</div>
  </div>
);

export type MapHostProps = {
  markers: Marker[];
  alarms: Alarm[];
  fusionTrajectories: FusionTrajectory[];
  isAdmin?: boolean;
  onMarkerAction?: () => void;
  isEmbed?: boolean;
};

function MapHostInner(props: MapHostProps) {
  const searchParams = useSearchParams();
  // MapLibre remains experimental until it has the same exact raion alarm contract as Leaflet SVG.
  // Keep the production alarm map on Leaflet to avoid the broken district GeoJSON runtime path.
  const useMapLibre =
    process.env.NEXT_PUBLIC_ENABLE_EXPERIMENTAL_MAPLIBRE === '1' && searchParams.get('maplibre') === '1';

  if (useMapLibre) {
    return <MapLibreMap {...props} />;
  }
  return <LeafletMap {...props} />;
}

function MapHost(props: MapHostProps) {
  return (
    <Suspense fallback={mapLoadingFallback}>
      <MapHostInner {...props} />
    </Suspense>
  );
}

export default memo(MapHost);
