'use client';

import { useCallback, useDeferredValue, useEffect, useRef, useState, memo } from 'react';
import maplibregl from 'maplibre-gl';
import 'maplibre-gl/dist/maplibre-gl.css';
import type { StyleSpecification } from 'maplibre-gl';
import type { FeatureCollection } from 'geojson';
import type { Alarm, FusionTrajectory, Marker } from '@/types';
import { THREAT_NAMES } from '@/types';
import { CACHE_VERSION } from '@/lib/constants';
import { formatKyivTime, buildMarkerPopup } from '@/lib/map/marker-popup-html';
import {
  hascListForStateAlarms,
  type OblastFeatureCollection,
} from '@/lib/map/alarm-hasc-filter';
import { markersToGeoJSON, maplibreIconId, markerIconUrl } from '@/lib/map/markers-to-geojson';
import type { ThreatMarkerFeatureCollection } from '@/lib/map/markers-to-geojson';
import { resolveThreatBearingDeg } from '@/lib/threat-bearing';
import {
  getBasemapUrl,
  isMobileMapProfile,
  pickBasemapKind,
  type MapBasemapKind,
} from '@/lib/map-leaflet-performance';
import {
  MAP_NIGHT,
  OBLAST_LINE_OPACITY,
  OBLAST_LINE_WIDTH,
  rasterNightPaint,
} from '@/lib/map/map-visual-tokens';
import { oblastAlarmFillOpacityCase } from '@/lib/map/map-alarm-opacity';
import {
  applyThreatMarkerFocus,
} from '@/lib/map/map-threat-focus';

const MAP_BOUNDS = { minLat: 44.2, maxLat: 52.4, minLng: 22.0, maxLng: 40.2 } as const;
/** Нормалізована текстура іконки (px) — `icon-size` = icon_px / NORM_ICON_PX */
const NORM_ICON_PX = 48;

let tooltipSingleton: HTMLDivElement | null = null;

function showMarkerTooltip(event: MouseEvent, marker: Marker, threatType: string) {
  if (!tooltipSingleton) {
    tooltipSingleton = document.createElement('div');
    tooltipSingleton.className = 'marker-tooltip';
    tooltipSingleton.id = 'active-tooltip';
    document.body.appendChild(tooltipSingleton);
  }
  const tooltip = tooltipSingleton;
  const typeName = THREAT_NAMES[threatType] || threatType;
  const trustRaw = (marker.display_trust_hint_uk || '').replace(/</g, '&lt;');
  const trustLine = trustRaw
    ? `<div class="tooltip-trust" style="font-size:11px;color:rgba(255,171,64,0.95);margin-bottom:6px;line-height:1.35;">${trustRaw}</div>`
    : '';
  const tipBrg = resolveThreatBearingDeg(marker);
  const tipCourse =
    tipBrg != null ? `<div class="tooltip-course">Курс ~${Math.round(tipBrg)}°</div>` : '';

  tooltip.innerHTML = `
    ${trustLine}
    <div class="tooltip-type" style="font-weight:600;font-size:13px;margin-bottom:4px;color:#ff2a5f;">${typeName}</div>
    <div class="tooltip-place" style="color:rgba(255,255,255,0.7);margin-bottom:2px;">${marker.place || 'Невідомо'}</div>
    ${tipCourse}
    ${marker.date ? `<div class="tooltip-time" style="color:rgba(255,255,255,0.4);font-size:11px;">${formatKyivTime(marker.date)}</div>` : ''}
  `;

  tooltip.style.opacity = '1';
  const rect = tooltip.getBoundingClientRect();
  let x = event.clientX + 15;
  let y = event.clientY + 15;
  if (x + rect.width > window.innerWidth) x = event.clientX - rect.width - 15;
  if (y + rect.height > window.innerHeight) y = event.clientY - rect.height - 15;
  tooltip.style.transform = `translate3d(${x}px, ${y}px, 0)`;
}

function hideMarkerTooltip() {
  if (tooltipSingleton) tooltipSingleton.style.opacity = '0';
}

function buildRasterStyle(basemap: MapBasemapKind, lowTileMode: boolean): StyleSpecification {
  const tiles = [getBasemapUrl(basemap)];
  const maxzoom = lowTileMode ? 16 : 19;
  const paint = rasterNightPaint(basemap === 'rasterVectorDark' ? 'rasterVectorDark' : 'googleHybrid');
  return {
    version: 8,
    glyphs: 'https://demotiles.maplibre.org/font/{fontstack}/{range}.pbf',
    sources: {
      basemap: {
        type: 'raster',
        tiles,
        tileSize: 256,
        attribution: '',
        maxzoom,
      },
    },
    layers: [
      {
        id: 'basemap',
        type: 'raster',
        source: 'basemap',
        paint: paint as never,
      },
    ],
  };
}

function collectIconJobs(markers: Marker[]): { id: string; url: string }[] {
  const seen = new Set<string>();
  const jobs: { id: string; url: string }[] = [];
  const origin = typeof window !== 'undefined' ? window.location.origin : '';
  for (const m of markers) {
    const id = maplibreIconId(m);
    if (seen.has(id)) continue;
    seen.add(id);
    const path = markerIconUrl(m);
    jobs.push({ id, url: `${origin}${path}` });
  }
  return jobs;
}

/**
 * Растеризує іконку до квадрата NORM_ICON_PX — передбачуваний `icon-size` на шарі.
 */
function ensureThreatImages(map: maplibregl.Map, jobs: { id: string; url: string }[]): Promise<void> {
  return Promise.all(
    jobs.map(
      ({ id, url }) =>
        new Promise<void>((resolve) => {
          if (map.hasImage(id)) {
            resolve();
            return;
          }
          const img = new Image();
          img.crossOrigin = 'anonymous';
          img.onload = () => {
            void (async () => {
              try {
                const c = document.createElement('canvas');
                c.width = NORM_ICON_PX;
                c.height = NORM_ICON_PX;
                const ctx = c.getContext('2d');
                if (!ctx) {
                  resolve();
                  return;
                }
                ctx.clearRect(0, 0, NORM_ICON_PX, NORM_ICON_PX);
                ctx.drawImage(img, 0, 0, NORM_ICON_PX, NORM_ICON_PX);
                const data = ctx.getImageData(0, 0, NORM_ICON_PX, NORM_ICON_PX);
                const isBallistic =
                  url.includes('icon_balistic') &&
                  typeof document !== 'undefined' &&
                  !document.documentElement.classList.contains('theme-light');
                if (isBallistic) {
                  const px = data.data;
                  for (let i = 0; i < px.length; i += 4) {
                    if (px[i + 3] > 8) {
                      px[i] = 255;
                      px[i + 1] = 255;
                      px[i + 2] = 255;
                    }
                  }
                }
                if (!map.hasImage(id)) map.addImage(id, data);
              } catch {
                try {
                  const { data } = await map.loadImage(url);
                  if (!map.hasImage(id)) map.addImage(id, data);
                } catch {
                  /* ignore */
                }
              } finally {
                resolve();
              }
            })();
          };
          img.onerror = () => resolve();
          img.src = url;
        }),
    ),
  ).then(() => undefined);
}

function emptyThreats(): ThreatMarkerFeatureCollection {
  return { type: 'FeatureCollection', features: [] };
}

interface MapLibreContainerProps {
  markers: Marker[];
  alarms: Alarm[];
  fusionTrajectories: FusionTrajectory[];
  isAdmin?: boolean;
  onMarkerAction?: () => void;
  isEmbed?: boolean;
}

function MapLibreContainer({
  markers,
  alarms,
  isAdmin,
  onMarkerAction,
  isEmbed = false,
}: MapLibreContainerProps) {
  const deferredMarkers = useDeferredValue(markers);
  const deferredAlarms = useDeferredValue(alarms);

  const mapElRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<maplibregl.Map | null>(null);
  const popupRef = useRef<maplibregl.Popup | null>(null);
  const oblastFcRef = useRef<OblastFeatureCollection | null>(null);
  const markerFocusMidRef = useRef<string | null>(null);
  const latestHascsRef = useRef<string[]>([]);
  const isAdminRef = useRef(!!isAdmin);

  const [mapReady, setMapReady] = useState(false);

  useEffect(() => {
    isAdminRef.current = !!isAdmin;
  }, [isAdmin]);

  useEffect(() => {
    if (!isAdmin) return;
    const w = window as unknown as {
      __ADMIN_SECRET?: string;
      __adminDeleteMarker?: (id: string, lat: number, lng: number, text: string) => void;
      __adminHideMarker?: (lat: number, lng: number, text: string) => void;
    };

    const adminJsonHeaders = (): Record<string, string> => {
      const secret =
        new URLSearchParams(window.location.search).get('admin_secret') ||
        w.__ADMIN_SECRET;
      return {
        'Content-Type': 'application/json',
        ...(secret ? { 'X-Auth-Secret': secret } : {}),
      };
    };

    w.__adminDeleteMarker = async (id: string, lat: number, lng: number, text: string) => {
      try {
        const res = await fetch('/api/admin/markers/delete', {
          method: 'POST',
          headers: adminJsonHeaders(),
          body: JSON.stringify({ id: id || undefined, lat, lng, text }),
        });
        if (res.ok) {
          popupRef.current?.remove();
          onMarkerAction?.();
        } else {
          const err = await res.json().catch(() => ({}));
          alert('Помилка видалення: ' + (err.error || res.status));
        }
      } catch {
        alert('Помилка мережі');
      }
    };

    w.__adminHideMarker = async (lat: number, lng: number, text: string) => {
      try {
        const res = await fetch('/api/admin/hidden/hide', {
          method: 'POST',
          headers: adminJsonHeaders(),
          body: JSON.stringify({ lat, lng, text, source: 'auto' }),
        });
        if (res.ok) {
          popupRef.current?.remove();
          onMarkerAction?.();
        } else {
          alert('Помилка приховування');
        }
      } catch {
        alert('Помилка мережі');
      }
    };

    return () => {
      delete w.__adminDeleteMarker;
      delete w.__adminHideMarker;
    };
  }, [isAdmin, onMarkerAction]);

  useEffect(() => {
    if (!mapElRef.current || mapRef.current) return;

    const ua = typeof navigator !== 'undefined' ? navigator.userAgent : undefined;
    const mtp = typeof navigator !== 'undefined' ? navigator.maxTouchPoints : undefined;
    const basemap = pickBasemapKind(isEmbed, ua);
    const lowTileMode = basemap === 'rasterVectorDark';
    const isMobile = isMobileMapProfile(ua, mtp);

    const mapResize = () => {
      try {
        mapRef.current?.resize();
      } catch {
        /* ignore */
      }
    };
    const onViewportResize = () => {
      mapResize();
    };
    window.addEventListener('resize', onViewportResize);
    window.addEventListener('orientationchange', onViewportResize);
    const libreVisualViewport = typeof window !== 'undefined' ? window.visualViewport : null;
    if (libreVisualViewport) {
      libreVisualViewport.addEventListener('resize', onViewportResize);
    }
    let mobileLibreKick1: number | null = null;
    let mobileLibreKick2: number | null = null;
    if (isMobile && !isEmbed) {
      mobileLibreKick1 = window.setTimeout(mapResize, 300);
      mobileLibreKick2 = window.setTimeout(mapResize, 900);
    }

    const map = new maplibregl.Map({
      container: mapElRef.current,
      style: buildRasterStyle(basemap, lowTileMode),
      center: [31.5, 48.5],
      zoom: 5,
      minZoom: 5,
      maxZoom: lowTileMode ? 16 : 19,
      maxBounds: [
        [18, 40],
        [44, 56],
      ],
      attributionControl: false,
      dragRotate: false,
      pitchWithRotate: false,
      touchPitch: false,
    });

    mapRef.current = map;

    map.on('load', () => {
      void (async () => {
        try {
          const oblastRes = await fetch(`/ukraine_oblasts.geojson?${CACHE_VERSION}`, { cache: 'force-cache' });
          const oblastData = (await oblastRes.json()) as OblastFeatureCollection;
          oblastFcRef.current = oblastData;

          map.addSource('oblasts', {
            type: 'geojson',
            data: oblastData as unknown as FeatureCollection,
          });

          map.addLayer({
            id: 'oblast-calm-dim',
            type: 'fill',
            source: 'oblasts',
            filter: ['literal', false],
            maxzoom: 11,
            paint: {
              'fill-color': MAP_NIGHT.calmDimFill,
              'fill-opacity': ['interpolate', ['linear'], ['zoom'], 5, 0.22, 8, 0.15, 11, 0.05],
            },
          });

          map.addLayer({
            id: 'oblast-alarm-fill',
            type: 'fill',
            source: 'oblasts',
            filter: ['!=', ['get', 'HASC_1'], '?'],
            paint: {
              'fill-color': [
                'case',
                ['in', ['get', 'HASC_1'], ['literal', [] as string[]]],
                MAP_NIGHT.alarmFillHex,
                'rgba(0,0,0,0)',
              ],
              'fill-opacity': ['case', ['in', ['get', 'HASC_1'], ['literal', [] as string[]]], 0.36, 0],
            },
          });

          map.addLayer({
            id: 'oblast-context-line',
            type: 'line',
            source: 'oblasts',
            filter: ['!=', ['get', 'HASC_1'], '?'],
            paint: {
              'line-color': MAP_NIGHT.oblastLine,
              'line-opacity': OBLAST_LINE_OPACITY as never,
              'line-width': OBLAST_LINE_WIDTH as never,
            },
          });

          // Do not load `ukraine_districts.geojson` here: that dataset has invalid/suspicious
          // geometry for runtime map rendering and can produce long "ray" artifacts.
          // Production raion alarms are rendered by Leaflet with `ukraine_districts_detailed.svg`.

          map.addSource('threats', {
            type: 'geojson',
            data: emptyThreats() as unknown as FeatureCollection,
            promoteId: 'mid',
          });

          map.addLayer({
            id: 'unclustered-point',
            type: 'symbol',
            source: 'threats',
            filter: ['!', ['has', 'point_count']],
            layout: {
              'icon-image': ['get', 'micon'],
              'icon-size': [
                '*',
                ['/', ['get', 'icon_px'], NORM_ICON_PX],
                ['case', ['boolean', ['feature-state', 'hover'], false], 1.1, 1],
              ],
              'icon-rotate': ['get', 'bearing'],
              'icon-rotation-alignment': 'map',
              'icon-allow-overlap': true,
              'icon-ignore-placement': true,
              'symbol-sort-key': ['get', 'prio'],
            },
            paint: {
              'icon-opacity': [
                'case',
                ['boolean', ['feature-state', 'hover'], false],
                ['min', 1, ['+', ['get', 'opacity'], 0.07]],
                ['get', 'opacity'],
              ],
            },
          });

          applyThreatMarkerFocus(map, null, NORM_ICON_PX);

          map.on('click', (e) => {
            const feats = map.queryRenderedFeatures(e.point, { layers: ['unclustered-point'] });
            if (feats.length) return;
            popupRef.current?.remove();
            markerFocusMidRef.current = null;
            applyThreatMarkerFocus(map, null, NORM_ICON_PX);
          });

          map.on('click', 'unclustered-point', (e) => {
            const f = e.features?.[0];
            if (!f || f.geometry.type !== 'Point') return;
            const coords = f.geometry.coordinates as [number, number];
            const rawJson = f.properties?._m;
            const mid = f.properties?.mid as string | undefined;
            if (typeof rawJson !== 'string') return;
            let m: Marker;
            try {
              m = JSON.parse(rawJson) as Marker;
            } catch {
              return;
            }
            const tt = m.threat_type || 'default';
            hideMarkerTooltip();
            popupRef.current?.remove();
            if (mid) {
              markerFocusMidRef.current = mid;
              applyThreatMarkerFocus(map, mid, NORM_ICON_PX);
            }
            const popup = new maplibregl.Popup({
              maxWidth: 'min(280px, calc(100vw - 24px))',
              closeButton: true,
              closeOnClick: true,
              offset: 14,
              className: 'neptun-maplibre-popup admin-marker-popup',
            })
              .setLngLat(coords)
              .setHTML(buildMarkerPopup(m, tt, isAdminRef.current))
              .addTo(map);
            popup.on('close', () => {
              markerFocusMidRef.current = null;
              applyThreatMarkerFocus(map, null, NORM_ICON_PX);
            });
            popupRef.current = popup;
          });

          const canHoverFine =
            typeof window !== 'undefined' &&
            window.matchMedia('(hover: hover) and (pointer: fine)').matches;
          let hoveredMarkerId: string | number | null = null;
          const clearMarkerHover = () => {
            if (hoveredMarkerId == null) return;
            try {
              map.removeFeatureState({ source: 'threats', id: hoveredMarkerId }, 'hover');
            } catch {
              /* ignore */
            }
            hoveredMarkerId = null;
          };

          map.on('mouseenter', 'unclustered-point', (e) => {
            map.getCanvas().style.cursor = 'pointer';
            const f = e.features?.[0];
            const rawJson = f?.properties?._m;
            if (canHoverFine && f?.properties?.mid != null) {
              clearMarkerHover();
              const mid = f.properties.mid as string;
              hoveredMarkerId = mid;
              try {
                map.setFeatureState({ source: 'threats', id: mid }, { hover: true });
              } catch {
                /* ignore */
              }
            }
            if (typeof rawJson !== 'string') return;
            try {
              const m = JSON.parse(rawJson) as Marker;
              const te = e.originalEvent;
              if (te && 'clientX' in te) showMarkerTooltip(te as MouseEvent, m, m.threat_type || 'default');
            } catch {
              /* ignore */
            }
          });
          map.on('mousemove', 'unclustered-point', (e) => {
            const f = e.features?.[0];
            const rawJson = f?.properties?._m;
            if (typeof rawJson !== 'string') return;
            try {
              const m = JSON.parse(rawJson) as Marker;
              const te = e.originalEvent;
              if (te && 'clientX' in te) showMarkerTooltip(te as MouseEvent, m, m.threat_type || 'default');
            } catch {
              /* ignore */
            }
          });
          map.on('mouseleave', 'unclustered-point', () => {
            map.getCanvas().style.cursor = '';
            clearMarkerHover();
            hideMarkerTooltip();
          });

          map.fitBounds(
            [
              [MAP_BOUNDS.minLng, MAP_BOUNDS.minLat],
              [MAP_BOUNDS.maxLng, MAP_BOUNDS.maxLat],
            ],
            { animate: false, padding: 8 },
          );

          /* WebView (Flutter): після layout інколи 0×0 canvas — один resize після першого idle. */
          const resizeOnce = () => {
            try {
              map.resize();
            } catch {
              /* ignore */
            }
          };
          if (isEmbed) {
            map.once('idle', () => requestAnimationFrame(resizeOnce));
            window.setTimeout(resizeOnce, 320);
          }

          setMapReady(true);
        } catch (err) {
          console.warn('MapLibre overlay init error:', err);
          setMapReady(true);
        }
      })();
    });

    return () => {
      window.removeEventListener('resize', onViewportResize);
      window.removeEventListener('orientationchange', onViewportResize);
      if (libreVisualViewport) {
        libreVisualViewport.removeEventListener('resize', onViewportResize);
      }
      if (mobileLibreKick1) window.clearTimeout(mobileLibreKick1);
      if (mobileLibreKick2) window.clearTimeout(mobileLibreKick2);
      setMapReady(false);
      popupRef.current?.remove();
      popupRef.current = null;
      map.remove();
      mapRef.current = null;
      oblastFcRef.current = null;
    };
  }, [isEmbed]);

  const applyAlarmPaint = useCallback((alarmsData: Alarm[]) => {
    const map = mapRef.current;
    if (!map?.isStyleLoaded()) return;
    const oblastFc = oblastFcRef.current;
    if (!oblastFc) return;

    const hascs = hascListForStateAlarms(alarmsData, oblastFc);
    latestHascsRef.current = hascs;

    if (map.getLayer('oblast-calm-dim')) {
      if (hascs.length === 0) {
        map.setFilter('oblast-calm-dim', ['literal', false]);
      } else {
        map.setFilter('oblast-calm-dim', [
          'all',
          ['!=', ['get', 'HASC_1'], '?'],
          ['!', ['in', ['get', 'HASC_1'], ['literal', hascs]]],
        ]);
      }
    }

    if (map.getLayer('oblast-alarm-fill')) {
      map.setPaintProperty('oblast-alarm-fill', 'fill-color', [
        'case',
        ['in', ['get', 'HASC_1'], ['literal', hascs]],
        MAP_NIGHT.alarmFillHex,
        'rgba(0,0,0,0)',
      ]);
      map.setPaintProperty('oblast-alarm-fill', 'fill-opacity', oblastAlarmFillOpacityCase(hascs, 0.36) as never);
    }
  }, []);

  useEffect(() => {
    if (!mapReady) return;
    applyAlarmPaint(deferredAlarms);
  }, [deferredAlarms, mapReady, applyAlarmPaint]);

  /** Легкий пульс opacity активних тривог (~2 Гц), без RAF кожного кадру. */
  useEffect(() => {
    if (!mapReady) return;
    const map = mapRef.current;
    if (!map?.isStyleLoaded()) return;
    const reducedMotion =
      typeof window !== 'undefined' && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (reducedMotion) return;

    const tick = () => {
      if (typeof document !== 'undefined' && document.visibilityState === 'hidden') return;
      const hascs = latestHascsRef.current;
      if (!map.getLayer('oblast-alarm-fill')) return;
      if (hascs.length === 0) return;
      const w = 0.5 + 0.5 * Math.sin(Date.now() / 700);
      if (hascs.length > 0) {
        const alpha = 0.26 + 0.14 * w;
        map.setPaintProperty('oblast-alarm-fill', 'fill-opacity', oblastAlarmFillOpacityCase(hascs, alpha) as never);
      }
    };

    const iv = window.setInterval(tick, 520);
    return () => window.clearInterval(iv);
  }, [mapReady, deferredAlarms]);

  useEffect(() => {
    if (!mapReady) return;
    const map = mapRef.current;
    if (!map?.isStyleLoaded()) return;

    let cancelled = false;
    const run = async () => {
      const fc = markersToGeoJSON(deferredMarkers);
      const jobs = collectIconJobs(deferredMarkers);
      await ensureThreatImages(map, jobs);
      if (cancelled) return;
      const src = map.getSource('threats') as maplibregl.GeoJSONSource | undefined;
      if (src) src.setData(fc as unknown as FeatureCollection);
      applyThreatMarkerFocus(map, markerFocusMidRef.current, NORM_ICON_PX);
    };

    const raf = requestAnimationFrame(() => {
      void run();
    });
    return () => {
      cancelled = true;
      cancelAnimationFrame(raf);
    };
  }, [deferredMarkers, mapReady]);

  return (
    <div className="w-full h-full relative bg-[var(--neptun-map-canvas)]">
      <div ref={mapElRef} id="maplibre-map" className="absolute inset-0 z-[1]" />
    </div>
  );
}

export default memo(MapLibreContainer);
